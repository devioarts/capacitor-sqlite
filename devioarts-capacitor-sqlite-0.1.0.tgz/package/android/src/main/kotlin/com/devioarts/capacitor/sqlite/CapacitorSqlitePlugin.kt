package com.devioarts.capacitor.sqlite

import android.util.Base64
import java.nio.charset.StandardCharsets
import com.getcapacitor.JSArray
import com.getcapacitor.JSObject
import com.getcapacitor.Plugin
import com.getcapacitor.PluginCall
import com.getcapacitor.PluginMethod
import com.getcapacitor.annotation.CapacitorPlugin
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import org.json.JSONArray
import org.json.JSONObject

@CapacitorPlugin(name = "CapacitorSqlite")
class CapacitorSqlitePlugin : Plugin() {

    private lateinit var impl: CapacitorSqlite
    private val sqliteExecutor = Executors.newSingleThreadExecutor { runnable ->
        Thread(runnable, "capacitor-sqlite")
    }

    override fun load() {
        impl = CapacitorSqlite(context)
    }

    override fun handleOnDestroy() {
        sqliteExecutor.shutdownNow()
        sqliteExecutor.awaitTermination(2, TimeUnit.SECONDS)
        if (::impl.isInitialized) {
            impl.closeAll()
        }
    }

    // MARK: - Unified response helpers

    private fun success(call: PluginCall, data: JSObject = JSObject()) {
        call.resolve(JSObject().put("success", true).put("data", data))
    }

    private fun failure(call: PluginCall, code: String, message: String, method: String) {
        val details = JSObject()
            .put("nativeCode", code)
            .put("nativeMessage", message)
            .put("source", "android-native")
        call.resolve(
            JSObject()
                .put("success", false)
                .put("error", JSObject()
                    .put("code", code)
                    .put("message", message)
                    .put("platform", "android")
                    .put("method", method)
                    .put("details", details)
                )
        )
    }

    private fun errorCode(e: Exception, fallback: String): String {
        return if (e is CapacitorSqliteException) e.code else fallback
    }

    private fun executeSqlite(block: () -> Unit) {
        sqliteExecutor.execute(block)
    }

    // MARK: - getPlatform

    @PluginMethod
    fun getPlatform(call: PluginCall) {
        success(call, JSObject().put("platform", "android"))
    }

    // MARK: - isAvailable

    @PluginMethod
    fun isAvailable(call: PluginCall) {
        success(call, JSObject().put("available", impl.isAvailable()))
    }

    // MARK: - open

    @PluginMethod
    fun open(call: PluginCall) {
        val database = call.getString("database")
            ?: return failure(call, "INVALID_PARAMS", "'database' is required", "open")
        val readonly = call.getBoolean("readonly", false) ?: false
        val directory = call.getString("directory")
        val migrations = try {
            jsonArrayToListOfMaps(call.getArray("migrations"), "migrations")
        } catch (e: IllegalArgumentException) {
            return failure(call, "MIGRATION_FAILED", e.message ?: "Invalid migrations", "open")
        }

        executeSqlite {
            try {
                impl.open(database, readonly, directory, migrations)
                success(call)
            } catch (e: Exception) {
                failure(call, errorCode(e, "OPEN_FAILED"), e.message ?: "open failed", "open")
            }
        }
    }

    // MARK: - close

    @PluginMethod
    fun close(call: PluginCall) {
        val database = call.getString("database")
            ?: return failure(call, "INVALID_PARAMS", "'database' is required", "close")

        executeSqlite {
            try {
                impl.close(database)
                success(call)
            } catch (e: Exception) {
                failure(call, errorCode(e, "CLOSE_FAILED"), e.message ?: "close failed", "close")
            }
        }
    }

    // MARK: - isOpen

    @PluginMethod
    fun isOpen(call: PluginCall) {
        val database = call.getString("database")
            ?: return failure(call, "INVALID_PARAMS", "'database' is required", "isOpen")

        executeSqlite {
            try {
                success(call, JSObject().put("open", impl.isOpen(database)))
            } catch (e: Exception) {
                failure(call, errorCode(e, "UNKNOWN"), e.message ?: "isOpen failed", "isOpen")
            }
        }
    }

    // MARK: - getVersion

    @PluginMethod
    fun getVersion(call: PluginCall) {
        val database = call.getString("database")
            ?: return failure(call, "INVALID_PARAMS", "'database' is required", "getVersion")

        executeSqlite {
            try {
                val version = impl.getVersion(database)
                success(call, JSObject().put("version", version))
            } catch (e: Exception) {
                failure(call, errorCode(e, "VERSION_FAILED"), e.message ?: "getVersion failed", "getVersion")
            }
        }
    }

    // MARK: - getSchemaVersion

    @PluginMethod
    fun getSchemaVersion(call: PluginCall) {
        val database = call.getString("database")
            ?: return failure(call, "INVALID_PARAMS", "'database' is required", "getSchemaVersion")

        executeSqlite {
            try {
                val version = impl.getSchemaVersion(database)
                success(call, JSObject().put("version", version))
            } catch (e: Exception) {
                failure(
                    call,
                    errorCode(e, "SCHEMA_VERSION_FAILED"),
                    e.message ?: "getSchemaVersion failed",
                    "getSchemaVersion"
                )
            }
        }
    }

    // MARK: - vacuum

    @PluginMethod
    fun vacuum(call: PluginCall) {
        val database = call.getString("database")
            ?: return failure(call, "INVALID_PARAMS", "'database' is required", "vacuum")

        executeSqlite {
            try {
                impl.vacuum(database)
                success(call)
            } catch (e: Exception) {
                failure(call, errorCode(e, "VACUUM_FAILED"), e.message ?: "vacuum failed", "vacuum")
            }
        }
    }

    // MARK: - execute

    @PluginMethod
    fun execute(call: PluginCall) {
        val database = call.getString("database")
            ?: return failure(call, "INVALID_PARAMS", "'database' is required", "execute")
        val stmts = try {
            jsonArrayToStringList(call.getArray("statements"), "statements")
        } catch (e: IllegalArgumentException) {
            return failure(call, "INVALID_PARAMS", e.message ?: "Invalid statements", "execute")
        }
        if (stmts.isEmpty()) {
            return failure(call, "INVALID_PARAMS", "'statements' must be a non-empty [string]", "execute")
        }
        val transaction = call.getBoolean("transaction", true) ?: true

        executeSqlite {
            try {
                val changes = impl.execute(database, stmts, transaction)
                success(call, JSObject().put("changes", changes))
            } catch (e: Exception) {
                failure(call, errorCode(e, "EXECUTE_FAILED"), e.message ?: "execute failed", "execute")
            }
        }
    }

    // MARK: - run

    @PluginMethod
    fun run(call: PluginCall) {
        val database = call.getString("database")
            ?: return failure(call, "INVALID_PARAMS", "'database' is required", "run")
        val statement = call.getString("statement")
            ?: return failure(call, "INVALID_PARAMS", "'statement' is required", "run")
        if (statement.trim().isEmpty()) {
            return failure(call, "INVALID_PARAMS", "'statement' is required", "run")
        }
        val values = try {
            jsonArrayToValueList(call.getArray("values"), "values")
        } catch (e: IllegalArgumentException) {
            return failure(call, "INVALID_PARAMS", e.message ?: "Invalid values", "run")
        }

        executeSqlite {
            try {
                val result = impl.run(database, statement, values)
                success(call, JSObject().put("changes", result.changes).put("lastInsertId", result.lastInsertId))
            } catch (e: Exception) {
                failure(call, errorCode(e, "EXECUTE_FAILED"), e.message ?: "run failed", "run")
            }
        }
    }

    // MARK: - runBatch

    @PluginMethod
    fun runBatch(call: PluginCall) {
        val database = call.getString("database")
            ?: return failure(call, "INVALID_PARAMS", "'database' is required", "runBatch")
        val set = try {
            jsonArrayToListOfMaps(call.getArray("set"), "set")
        } catch (e: IllegalArgumentException) {
            return failure(call, "INVALID_PARAMS", e.message ?: "Invalid set", "runBatch")
        }
        if (set.isEmpty()) {
            return failure(call, "INVALID_PARAMS", "'set' must be a non-empty array", "runBatch")
        }
        val transaction = call.getBoolean("transaction", true) ?: true

        executeSqlite {
            try {
                val result = impl.runBatch(database, set, transaction)
                success(call, JSObject().put("changes", result.changes).put("lastInsertId", result.lastInsertId))
            } catch (e: Exception) {
                failure(call, errorCode(e, "EXECUTE_FAILED"), e.message ?: "runBatch failed", "runBatch")
            }
        }
    }

    // MARK: - query

    @PluginMethod
    fun query(call: PluginCall) {
        val database = call.getString("database")
            ?: return failure(call, "INVALID_PARAMS", "'database' is required", "query")
        val statement = call.getString("statement")
            ?: return failure(call, "INVALID_PARAMS", "'statement' is required", "query")
        if (statement.trim().isEmpty()) {
            return failure(call, "INVALID_PARAMS", "'statement' is required", "query")
        }
        val values = try {
            jsonArrayToValueList(call.getArray("values"), "values")
        } catch (e: IllegalArgumentException) {
            return failure(call, "INVALID_PARAMS", e.message ?: "Invalid values", "query")
        }

        executeSqlite {
            try {
                val rows = impl.query(database, statement, values)
                val result = JSArray()
                for (row in rows) {
                    val obj = JSObject()
                    for ((key, value) in row) {
                        when (value) {
                            null         -> obj.put(key, JSONObject.NULL)
                            is ByteArray -> obj.put(key, SQLiteHelpers.BLOB_PREFIX + Base64.encodeToString(value, Base64.NO_WRAP))
                            is String    -> obj.put(key, encodeText(value))
                            else         -> obj.put(key, value)
                        }
                    }
                    result.put(obj)
                }
                success(call, JSObject().put("rows", result))
            } catch (e: Exception) {
                failure(call, errorCode(e, "QUERY_FAILED"), e.message ?: "query failed", "query")
            }
        }
    }

    // MARK: - beginTransaction

    @PluginMethod
    fun beginTransaction(call: PluginCall) {
        val database = call.getString("database")
            ?: return failure(call, "INVALID_PARAMS", "'database' is required", "beginTransaction")

        executeSqlite {
            try {
                impl.beginTransaction(database)
                success(call)
            } catch (e: Exception) {
                failure(call, errorCode(e, "TRANSACTION_FAILED"), e.message ?: "beginTransaction failed", "beginTransaction")
            }
        }
    }

    // MARK: - commitTransaction

    @PluginMethod
    fun commitTransaction(call: PluginCall) {
        val database = call.getString("database")
            ?: return failure(call, "INVALID_PARAMS", "'database' is required", "commitTransaction")

        executeSqlite {
            try {
                impl.commitTransaction(database)
                success(call)
            } catch (e: Exception) {
                failure(call, errorCode(e, "TRANSACTION_FAILED"), e.message ?: "commitTransaction failed", "commitTransaction")
            }
        }
    }

    // MARK: - rollbackTransaction

    @PluginMethod
    fun rollbackTransaction(call: PluginCall) {
        val database = call.getString("database")
            ?: return failure(call, "INVALID_PARAMS", "'database' is required", "rollbackTransaction")

        executeSqlite {
            try {
                impl.rollbackTransaction(database)
                success(call)
            } catch (e: Exception) {
                failure(call, errorCode(e, "TRANSACTION_FAILED"), e.message ?: "rollbackTransaction failed", "rollbackTransaction")
            }
        }
    }

    // MARK: - JSON bridge helpers

    private fun jsonArrayToValueList(arr: JSArray?, label: String): List<Any?> {
        arr ?: return emptyList()
        return (0 until arr.length()).map { i ->
            val v = arr.get(i)
            unwrapJsonValue(v, "$label[$i]")
        }
    }

    private fun jsonArrayToStringList(arr: JSArray?, label: String): List<String> {
        arr ?: return emptyList()
        return (0 until arr.length()).map { i ->
            val value = arr.get(i) as? String
                ?: throw IllegalArgumentException("'$label[$i]' must be a string")
            require(value.trim().isNotEmpty()) { "'$label[$i]' must be a non-empty string" }
            value
        }
    }

    private fun jsonArrayToListOfMaps(arr: JSArray?, label: String): List<Map<String, Any?>> {
        arr ?: return emptyList()
        return (0 until arr.length()).map { i ->
            val obj = try {
                arr.getJSONObject(i)
            } catch (_: Exception) {
                throw IllegalArgumentException("'$label[$i]' must be an object")
            }
            val map = mutableMapOf<String, Any?>()
            val keys = obj.keys()
            while (keys.hasNext()) {
                val key = keys.next()
                val v = obj.get(key)
                map[key] = unwrapJsonValue(v, "$label[$i].$key")
            }
            map
        }
    }

    private fun unwrapJsonValue(v: Any, label: String): Any? = when (v) {
        JSONObject.NULL -> null
        is JSONArray    -> (0 until v.length()).map { i ->
            val item = v.get(i)
            unwrapJsonValue(item, "$label[$i]")
        }
        is JSONObject   -> throw IllegalArgumentException("'$label' must not be an object")
        else -> v
    }

    private fun encodeText(value: String): String {
        if (!value.startsWith(SQLiteHelpers.BLOB_PREFIX) && !value.startsWith(SQLiteHelpers.TEXT_PREFIX)) {
            return value
        }
        val encoded = Base64.encodeToString(value.toByteArray(StandardCharsets.UTF_8), Base64.NO_WRAP)
        return SQLiteHelpers.TEXT_PREFIX + encoded
    }
}
